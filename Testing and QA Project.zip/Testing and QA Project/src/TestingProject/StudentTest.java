package TestingProject;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class StudentTest {

    //Constructor tests

    @Test
    public void testConstructor_ValidValues() {
        Student s = new Student("9700", "Abdullah");

        assertEquals("9700", s.getId());
        assertEquals("Abdullah", s.getName());
        assertNotNull(s.getCourses());
        assertTrue(s.getCourses().isEmpty());
    }

    @Test
    public void testConstructor_NullIdDefaultsTo0000() {
        Student s = new Student(null, "Abdullah");

        assertEquals("0000", s.getId());
        assertEquals("Abdullah", s.getName());
    }

    @Test
    public void testConstructor_EmptyIdDefaultsTo0000() {
        Student s = new Student("", "Abdullah");

        assertEquals("0000", s.getId());
        assertEquals("Abdullah", s.getName());
    }

    @Test
    public void testConstructor_NullNameDefaultsToUnknown() {
        Student s = new Student("9700", null);

        assertEquals("9700", s.getId());
        assertEquals("Unknown", s.getName());
    }

    @Test
    public void testConstructor_EmptyNameDefaultsToUnknown() {
        Student s = new Student("9700", "");

        assertEquals("9700", s.getId());
        assertEquals("Unknown", s.getName());
    }

    //enrollCourse and getCourses tests

    @Test
    public void testEnrollCourse_AddsCourseToList() {
        Student s = new Student("9700", "Abdullah");
        Course c = new Course("Quran", 3, "A");

        s.enrollCourse(c);

        List<Course> courses = s.getCourses();
        assertEquals(1, courses.size());
        assertSame(c, courses.get(0));
    }

    @Test
    public void testEnrollCourse_MultipleCourses() {
        Student s = new Student("9700", "Abdullah");
        Course c1 = new Course("Quran", 3, "A");
        Course c2 = new Course("Math", 4, "B");

        s.enrollCourse(c1);
        s.enrollCourse(c2);

        List<Course> courses = s.getCourses();
        assertEquals(2, courses.size());
        assertSame(c1, courses.get(0));
        assertSame(c2, courses.get(1));
    }

    @Test
    public void testEnrollCourse_NullCourseIsIgnored() {
        Student s = new Student("9700", "Abdullah");

        s.enrollCourse(null);

        assertTrue(s.getCourses().isEmpty());
    }

    //getId and getName tests

    @Test
    public void testGetId_ReturnsId() {
        Student s = new Student("5500", "Abdulrahman");

        assertEquals("5500", s.getId());
    }

    @Test
    public void testGetName_ReturnsName() {
        Student s = new Student("5500", "Abdulrahman");

        assertEquals("Abdulrahman", s.getName());
    }

    // calculateGPA tests

    @Test
    public void testCalculateGPA_NoCoursesReturnsZero() {
        Student s = new Student("9700", "Abdullah");

        assertEquals(0.0, s.calculateGPA(), 0.0001);
    }

    @Test
    public void testCalculateGPA_SingleCourse() {
        Student s = new Student("9700", "Abdullah");
        Course c = new Course("Quran", 3, "A"); // 4.0 points

        s.enrollCourse(c);

        assertEquals(4.0, s.calculateGPA(), 0.0001);
    }

    @Test
    public void testCalculateGPA_TwoCoursesMixedGrades() {
        Student s = new Student("9700", "Abdullah");
        Course c1 = new Course("Quran", 3, "A"); // 4.0
        Course c2 = new Course("Math", 3, "B"); // 3.0

        s.enrollCourse(c1);
        s.enrollCourse(c2);


        assertEquals(3.5, s.calculateGPA(), 0.0001);
    }

    @Test
    public void testCalculateGPA_UsesCreditHoursWeighting() {
        Student s = new Student("9700", "Abdullah");
        Course c1 = new Course("Quran", 6, "A"); // 4.0
        Course c2 = new Course("Lab", 1, "C");  // 2.0

        s.enrollCourse(c1);
        s.enrollCourse(c2);


        double expectedGpa = 26.0 / 7.0;

        assertEquals(expectedGpa, s.calculateGPA(), 0.0001);
    }

    @Test
    public void testCalculateGPA_InvalidGradeCourseCountsAsZeroPoints() {
        Student s = new Student("9700", "Abdullah");
        Course c1 = new Course("Quran", 3, "A"); // 4.0
        Course c2 = new Course("Weird", 3, "Z"); // becomes F -> 0.0

        s.enrollCourse(c1);
        s.enrollCourse(c2);


        assertEquals(2.0, s.calculateGPA(), 0.0001);
    }
}
