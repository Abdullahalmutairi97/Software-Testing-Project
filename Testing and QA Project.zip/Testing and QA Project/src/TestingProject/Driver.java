package TestingProject;

public class Driver {
    public static void main(String[] args) {
        GradeCalculator gc = new GradeCalculator();

        int[] epTests = { -1, 40, 65, 75, 85, 95, 101 };
        System.out.println("=== Equivalence Partitioning ===");
        for (int score : epTests) {
            System.out.println("Score: " + score + " -> " + gc.calculateLetterGrade(score));
        }

        int[] bvaTests = { 59, 60, 69, 70, 79, 80, 89, 90 };
        System.out.println("\n=== Boundary Value Analysis ===");
        for (int score : bvaTests) {
            System.out.println("Score: " + score + " -> " + gc.calculateLetterGrade(score));
        }
    }
}
