package TestingProject;

import org.junit.Test;
import static org.junit.Assert.*;

public class GradeCalculatorTest {

    //Invalid score tests

    @Test
    public void testScoreBelowZero_ReturnsInvalid() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("Invalid", gc.calculateLetterGrade(-1));
    }

    @Test
    public void testScoreAboveHundred_ReturnsInvalid() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("Invalid", gc.calculateLetterGrade(101));
    }

    //Normal range tests

    @Test
    public void testScoreInFRange() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("F", gc.calculateLetterGrade(0));
        assertEquals("F", gc.calculateLetterGrade(40));
        assertEquals("F", gc.calculateLetterGrade(59));
    }

    @Test
    public void testScoreInDRange() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("D", gc.calculateLetterGrade(60));
        assertEquals("D", gc.calculateLetterGrade(65));
        assertEquals("D", gc.calculateLetterGrade(69));
    }

    @Test
    public void testScoreInCRange() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("C", gc.calculateLetterGrade(70));
        assertEquals("C", gc.calculateLetterGrade(75));
        assertEquals("C", gc.calculateLetterGrade(79));
    }

    @Test
    public void testScoreInBRange() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("B", gc.calculateLetterGrade(80));
        assertEquals("B", gc.calculateLetterGrade(85));
        assertEquals("B", gc.calculateLetterGrade(89));
    }

    @Test
    public void testScoreInARange() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("A", gc.calculateLetterGrade(90));
        assertEquals("A", gc.calculateLetterGrade(95));
        assertEquals("A", gc.calculateLetterGrade(100));
    }

    //Boundary value tests

    @Test
    public void testBoundary_59To60() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("F", gc.calculateLetterGrade(59));
        assertEquals("D", gc.calculateLetterGrade(60));
    }

    @Test
    public void testBoundary_69To70() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("D", gc.calculateLetterGrade(69));
        assertEquals("C", gc.calculateLetterGrade(70));
    }

    @Test
    public void testBoundary_79To80() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("C", gc.calculateLetterGrade(79));
        assertEquals("B", gc.calculateLetterGrade(80));
    }

    @Test
    public void testBoundary_89To90() {
        GradeCalculator gc = new GradeCalculator();
        assertEquals("B", gc.calculateLetterGrade(89));
        assertEquals("A", gc.calculateLetterGrade(90));
    }
}
