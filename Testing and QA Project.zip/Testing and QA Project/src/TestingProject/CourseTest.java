package TestingProject;

import org.junit.Test;
import static org.junit.Assert.*;

public class CourseTest {

    //Constructor tests

    @Test
    public void testConstructor_ValidValues() {
        Course c = new Course("Quran", 3, "A");

        assertEquals("Quran", c.getCourseName());
        assertEquals(4, c.getCreditHours());
        assertEquals("A", c.getLetterGrade());
    }

    @Test
    public void testConstructor_NullNameDefaultsToUnknown() {
        Course c = new Course(null, 3, "B");

        assertEquals("Unknown", c.getCourseName());
        assertEquals(2, c.getCreditHours());
        assertEquals("C", c.getLetterGrade());
    }

    @Test
    public void testConstructor_EmptyNameDefaultsToUnknown() {
        Course c = new Course("", 4, "C");

        assertEquals("Unknown", c.getCourseName());
        assertEquals(4, c.getCreditHours());
        assertEquals("B", c.getLetterGrade());
    }

    @Test
    public void testConstructor_CreditHoursBelowRangeDefaultsTo3() {
        Course c = new Course("ComputerOrg", 0, "A");

        assertEquals("ComputerOrg", c.getCourseName());
        assertEquals(3, c.getCreditHours()); // default
        assertEquals("A", c.getLetterGrade());
    }

    @Test
    public void testConstructor_CreditHoursAboveRangeDefaultsTo3() {
        Course c = new Course("ComputerOrg", 10, "A");

        assertEquals("ComputerOrg", c.getCourseName());
        assertEquals(3, c.getCreditHours()); // default
        assertEquals("A", c.getLetterGrade());
    }

    @Test
    public void testConstructor_CreditHoursLowerBoundary1() {
        Course c = new Course("Algorithms", 1, "B");

        assertEquals(1, c.getCreditHours());
    }

    @Test
    public void testConstructor_CreditHoursUpperBoundary6() {
        Course c = new Course("Algorithms", 6, "B");

        assertEquals(6, c.getCreditHours());
    }

    @Test
    public void testConstructor_ValidLetterGradeStored() {
        Course c = new Course("History", 3, "C");

        assertEquals("C", c.getLetterGrade());
    }

    @Test
    public void testConstructor_InvalidLetterGradeDefaultsToF() {
        Course c = new Course("History", 3, "Z");

        assertEquals("F", c.getLetterGrade());
    }

    @Test
    public void testConstructor_NullLetterGradeDefaultsToF() {
        Course c = new Course("History", 3, null);

        assertEquals("F", c.getLetterGrade());
    }

    //Getter tests

    @Test
    public void testGetCourseName_ReturnsStoredName() {
        Course c = new Course("Math", 3, "A");

        assertEquals("Math", c.getCourseName());
    }

    @Test
    public void testGetCourseName_ReturnsUnknownWhenDefaulted() {
        Course c = new Course("", 3, "A");

        assertEquals("Unknown", c.getCourseName());
    }

    @Test
    public void testGetCreditHours_ReturnsStoredValue() {
        Course c = new Course("Quran", 5, "A");

        assertEquals(5, c.getCreditHours());
    }

    @Test
    public void testGetCreditHours_ReturnsDefault3WhenOutOfRange() {
        Course cLow = new Course("Quran", 0, "A");
        Course cHigh = new Course("Science", 7, "B");

        assertEquals(3, cLow.getCreditHours());
        assertEquals(3, cHigh.getCreditHours());
    }

    @Test
    public void testGetLetterGrade_ReturnsStoredGrade() {
        Course c = new Course("Quran", 3, "B");

        assertEquals("B", c.getLetterGrade());
    }

    //getGradePoint tests

    @Test
    public void testGetGradePoint_A() {
        Course c = new Course("Quran", 3, "A");

        assertEquals(4.0, c.getGradePoint(), 0.0001);
    }

    @Test
    public void testGetGradePoint_B() {
        Course c = new Course("Quran", 3, "B");

        assertEquals(3.0, c.getGradePoint(), 0.0001);
    }

    @Test
    public void testGetGradePoint_C() {
        Course c = new Course("Quran", 3, "C");

        assertEquals(2.0, c.getGradePoint(), 0.0001);
    }

    @Test
    public void testGetGradePoint_D() {
        Course c = new Course("Quran", 3, "D");

        assertEquals(1.0, c.getGradePoint(), 0.0001);
    }

    @Test
    public void testGetGradePoint_F() {
        Course c = new Course("Quran", 3, "F");

        assertEquals(0.0, c.getGradePoint(), 0.0001);
    }

    @Test
    public void testGetGradePoint_InvalidGradeBecomesFThen0() {
        Course c = new Course("Quran", 3, "Z"); // will become F

        assertEquals("F", c.getLetterGrade());
        assertEquals(0.0, c.getGradePoint(), 0.0001);
    }
}
